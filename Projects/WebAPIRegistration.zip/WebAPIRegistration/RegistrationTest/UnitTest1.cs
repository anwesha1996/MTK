﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace RegistrationTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
