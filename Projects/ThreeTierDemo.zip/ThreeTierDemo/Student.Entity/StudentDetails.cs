﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student.Entity
{
    public class StudentDetails
    {
        public string StudentName { get; set; }
        public string EmailId { get; set; }
        public string ContactID { get; set; }

    }
}
